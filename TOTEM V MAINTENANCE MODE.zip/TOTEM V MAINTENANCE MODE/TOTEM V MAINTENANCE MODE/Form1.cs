﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Diagnostics;

namespace TOTEM_V_MAINTENANCE_MODE
{
    public partial class Form1 : Form
    {
        int newNUM = 0;
       // string colourDatasOutput;
        char cardCharacter;

        public Form1()
        {
            InitializeComponent();
        }

        

       

        private void Form1_Load(object sender, EventArgs e)
        {
            {
                //Get all ports
                string[] ports = SerialPort.GetPortNames();
                comboBox1.Items.AddRange(ports);
                comboBox1.SelectedIndex = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
         

            {
                try
                {
                    //Open port
                    serialPort1.PortName = comboBox1.Text;
                   // serialPort1.Open();
                   


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

                serialPort1.Open();
                if (serialPort1.IsOpen) {

                serialPort1.WriteLine("h");
                String OutputPortData = Convert.ToString(serialPort1.ReadExisting());
                Console.WriteLine(OutputPortData);
                textBox1.Text = OutputPortData;

            
                serialPort1.Close();


               
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            {
                textBox1.Text = "";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            {
                textBox1.Text = "";
                
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            if (serialPort1.IsOpen)
            {
                
                   
                    serialPort1.WriteLine("g");
                    string distanceData = serialPort1.ReadExisting();





                textBox1.Text = Convert.ToString(distanceData);
                
                serialPort1.Close();
                
                
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            

            


            
 

        }

        private void button10_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.WriteLine("i");
            serialPort1.ReadExisting();

            serialPort1.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            if (comboBox2.SelectedIndex == 0)
            {
                serialPort1.WriteLine("d");
                textBox1.Text = "0 degrees";
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                serialPort1.WriteLine("e");
                textBox1.Text = "90 degrees";
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                serialPort1.WriteLine("f");
                textBox1.Text = "180 degrees";

            }
            serialPort1.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            if (comboBox3.SelectedIndex == 0)
            {
                textBox1.Text = "UP";
                serialPort1.WriteLine("a");
            }
            else if (comboBox3.SelectedIndex == 1)
            {
                textBox1.Text = "DOWN";
                serialPort1.WriteLine("b");
                
            }
            else if (comboBox3.SelectedIndex == 2)
            {
                textBox1.Text = "UP and DOWN";
                serialPort1.WriteLine("c");
               

            }
            serialPort1.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            {
                textBox1.Text = "";

            }
        }
    }
}
